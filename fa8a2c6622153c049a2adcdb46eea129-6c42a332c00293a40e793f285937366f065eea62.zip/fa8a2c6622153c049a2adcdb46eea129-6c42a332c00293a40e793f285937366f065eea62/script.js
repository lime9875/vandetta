document.addEventListener('DOMContentLoaded', () => {
    const currencyPricesDiv = document.getElementById('currency-prices');

    // بيانات افتراضية للعملات
    const currencies = [
        { name: 'الدولار الأمريكي', price: 1.0 },
        { name: 'اليورو', price: 0.85 },
        { name: 'الجنيه الإسترليني', price: 0.75 },
        { name: 'الين الياباني', price: 110.0 }
    ];

    // عرض أسعار العملات
    currencies.forEach(currency => {
        const currencyElement = document.createElement('div');
        currencyElement.textContent = `${currency.name}: ${currency.price} $`;
        currencyElement.setAttribute('data-name', currency.name);
        currencyElement.setAttribute('data-price', currency.price);
        currencyPricesDiv.appendChild(currencyElement);
    });

    // تفعيل زر الشراء
    document.getElementById('buy-button').addEventListener('click', () => {
        const selectedCurrency = currencyPricesDiv.querySelector('div[data-name="الدولار الأمريكي"]');
        const currencyName = selectedCurrency.getAttribute('data-name');
        const currencyPrice = selectedCurrency.getAttribute('data-price');
        alert(`تم شراء ${currencyName} بسعر ${currencyPrice} $`);
    });

    // تفعيل زر البيع
    document.getElementById('sell-button').addEventListener('click', () => {
        const selectedCurrency = currencyPricesDiv.querySelector('div[data-name="الدولار الأمريكي"]');
        const currencyName = selectedCurrency.getAttribute('data-name');
        const currencyPrice = selectedCurrency.getAttribute('data-price');
        alert(`تم بيع ${currencyName} بسعر ${currencyPrice} $`);
    });
});
document.addEventListener('DOMContentLoaded', () => {
    const currencyPricesDiv = document.getElementById('currency-prices');

    // وظيفة لجلب أسعار العملات
    async function fetchCurrencyPrices() {
        try {
            const response = await fetch('https://api.exchangerate-api.com/v4/latest/USD'); // استبدل برابط API المناسب
            const data = await response.json();
            displayCurrencyPrices(data.rates);
        } catch (error) {
            console.error('Error fetching currency data:', error);
        }
    }

    function displayCurrencyPrices(rates) {
        for (const [currency, price] of Object.entries(rates)) {
            const currencyElement = document.createElement('div');
            currencyElement.textContent = `${currency}: ${price}`;
            currencyElement.setAttribute('data-name', currency);
            currencyElement.setAttribute('data-price', price);
            currencyPricesDiv.appendChild(currencyElement);
        }
    }

    // جلب الأسعار عند تحميل الصفحة
    fetchCurrencyPrices();

    // تفعيل زر الشراء
    document.getElementById('buy-button').addEventListener('click', () => {
        const selectedCurrency = currencyPricesDiv.querySelector('div[data-name="EUR"]'); // مثال: اليورو
        const currencyName = selectedCurrency.getAttribute('data-name');
        const currencyPrice = selectedCurrency.getAttribute('data-price');
        alert(`تم شراء ${currencyName} بسعر ${currencyPrice}`);
    });

    // تفعيل زر البيع
    document.getElementById('sell-button').addEventListener('click', () => {
        const selectedCurrency = currencyPricesDiv.querySelector('div[data-name="EUR"]');
        const currencyName = selectedCurrency.getAttribute('data-name');
        const currencyPrice = selectedCurrency.getAttribute('data-price');
        alert(`تم بيع ${currencyName} بسعر ${currencyPrice}`);
    });
});
document.getElementById('registration-form').addEventListener('submit', (e) => {
    e.preventDefault();
    
    const username = document.getElementById('username').value;
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;

    // هنا يمكنك إرسال البيانات إلى الخادم (API) لمعالجة التسجيل
    alert(`تم تسجيل ${username} بنجاح!`);
});
document.getElementById('login-form').addEventListener('submit', (e) => {
    e.preventDefault();
    
    const email = document.getElementById('login-email').value;
    const password = document.getElementById('login-password').value;

    // هنا يمكنك إرسال البيانات إلى الخادم (API) لمعالجة تسجيل الدخول
    alert(`تم تسجيل دخول ${email} بنجاح!`);
});
