 document.getElementById('toggle-mode').addEventListener('click', function() {
    document.body.classList.toggle('dark-mode');
    const sections = document.querySelectorAll('section');
    sections.forEach(section => section.classList.toggle('dark-mode'));
    const footer = document.querySelector('footer');
    footer.classList.toggle('dark-mode');
    const header = document.querySelector('header');
    header.classList.toggle('dark-mode');
});

// existing event listeners for forms
document.getElementById('signup-form').addEventListener('submit', function(event) {
    event.preventDefault();
    alert('تم تسجيلك بنجاح!');
});

document.getElementById('login-form').addEventListener('submit', function(event) {
    event.preventDefault();
    alert('تسجيل الدخول ناجح!');
});

